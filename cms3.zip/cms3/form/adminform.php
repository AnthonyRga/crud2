<?php

//coreUI script bootstrap
echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/coreui/dist/css/coreui.min.css">';
echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/icons/css/coreui-icons.min.css">';
echo '<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>';
echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>';
echo '<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>';
echo '<script src="https://unpkg.com/@coreui/coreui/dist/js/coreui.min.js"></script>';

// formHome
function formHome()
{
    echo '<form method="post" action="">';
    echo '<label for="titre">Titre&nbsp;&nbsp;:</label>';
    echo '<input type="text" name="titre">';
    echo '<br>';
    echo '<label for="texte">Texte :</label>';
    echo '<input type="text" name="texte">';
    echo '<br>';
    echo '<button class="btn btn-secondary" type="submit">Valider</button>';
    echo '</form>';
}
// formAge
function formAge(){

    echo '<form method="post" action="">';
    echo '<label for="age">Age :</label>';
    echo '<input type="text" value="$ageId" name="age" >';
    echo '<button class="btn btn-secondary" type="submit">Valider</button>';
    echo '</form>';
}
// formCommune
function formCommune()
{
    echo '<form method="post" action="">';
    echo '<label for="commune">Commune :</label>';
    echo '<input type="text" name="commune">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formPresentation
function formPresentation()
{
    echo '<form method="post" action="">';
    echo '<label for="presentation">Nouvelle presentation :</label>';
    echo '<input type="text" name="presentation">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formHobbys "ajouter un hobby"
function formHobbys()
{
    echo '<form method="post" action="">';
    echo '<label for="hobbys">Ajouter un hobby</label>';
    echo '<input type="text" name="hobbys">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formHobbys2 "update un hobby"
function formHobbys2()
{
    echo '<form method="post" action="">';
    echo '<label for="hobbys">Update un hobby</label>';
    echo '<input type="text" name="hobbys">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formPerso email
function formPerso()
{
    echo '<form method="post" action="">';
    echo '<label for="personnel">Modifier Email :</label>';
    echo '<input type="text" name="personnel">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formLinked footer
function formLinked()
{
    echo '<form method="post" action="">';
    echo '<label for="linkedin">Modifier LinkedIn :</label>';
    echo '<input type="text" name="linkedin">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formFace footer
function formFace()
{
    echo '<form method="post" action="">';
    echo '<label for="facebook">Modifier Facebook :</label>';
    echo '<input type="text" name="facebook">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formComp "insérer une compétence"
function formComp()
{
    echo '<form method="post" action="">';
    echo '<label for="competence">Ajouter une compétence</label>';
    echo '<input type="text" name="competence">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// forComp2 "update une compétence"
function formComp2()
{
    echo '<form method="post" action="">';
    echo '<label for="competence">Update une compétence</label>';
    echo '<input type="text" name="competence">';
    echo '<button class="btn btn-pill btn-primary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formImage
function formImage(){
    echo '<form method="post" action="" enctype="multipart/form-data">';
    echo '<label for="nom_dossier">Nom dossier&nbsp;&nbsp;</label>';
    echo '<input type="text" name="nom_dossier" required>';
    echo '<br>';
    echo '<label for="nom_fichier">Nom fichier&nbsp;&nbsp;&nbsp;</label>';
    echo '<input type="text" name="nom_fichier" required>';
    echo '<br>';
    echo '<label for="extension">Extension&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>';
    echo '<input type="text" name="extension" required>';
    echo '<br>';
    echo '<label for="position">Veuillez confirmer la page de l\'image</label>';
    echo '<input type="text" name="position" required>';
    echo '<br>';
    echo '<label for="avatar">Choisir image</label>';
    echo '<input type="file" name="avatar" id="avatar" required>';
    echo '<br>';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
// formLink
function formLink()
{
    echo '<form method="post" action="" enctype="multipart/form-data">';

    echo '<label for="link">Ajouter un lien</label>';
    echo '<input type="text" name="link">';
    echo '<br>';

    echo '<label for="nom_dossier">Nom dossier</label>';
    echo '<input type="text" name="nom_dossier" required>';
    echo '<br>';

    echo '<label for="nom_fichier">Nom fichier</label>';
    echo '<input type="text" name="nom_fichier" required>';
    echo '<br>';
    echo '<label for="extension">Extension</label>';
    echo '<input type="text" name="extension" required>';
    echo '<br>';
    
    echo '<label for="position">Veuillez confirmer la page (portfolio)</label>';
    echo '<input type="text" name="position" required>';
    echo '<br>';

    echo '<label for="avatar">Choisir image</label>';
    echo '<input type="file" name="avatar" id="avatar" required>';
    echo '<br>';

    echo '<label for="description">Description:</label>';
    echo '<input type="text" name="description">';
    echo '<br>';


    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';

}
// formDescription
function formDescription()
{
    echo '<form method="post" action="">';
    echo '<label for="description">Modifier description </label>';
    echo '<input type="text" name="description">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}
function formLink2()
{
    echo '<form method="post" action="">';
    echo '<label for="link">Modifier lien du projet</label>';
    echo '<input type="text" name="link">';
    echo '<button class="btn btn-secondary" type="submit">Envoyer</button>';
    echo '</form>';
}